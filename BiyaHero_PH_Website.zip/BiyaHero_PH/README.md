# BiyaHero PH — Commuter Board prototype

A responsive HTML, CSS, and JavaScript prototype inspired by the supplied brief.

## Run it
1. Extract the ZIP file.
2. Open `index.html` in a browser.
3. For best results while editing, open the folder in VS Code and use Live Server.

## Included interactions
- Choose origin and destination and swap them.
- Select one of three sample route options and view route steps/fare breakdown.
- Save route details to browser local storage.
- Submit a quick commuter report, displayed locally in the current browser.

## Important prototype limitations
- All routes, fares, waiting times, and community updates are sample/demo data, not live verified information.
- Reports are stored only in the browser and are not shared with other users.
- Saving a route does not make the entire website work offline. True offline support would need a service worker and a deployed HTTPS site.
- For a production version, use verified route/fare data, a shared backend, moderation, timestamps, location/privacy safeguards, and a clear report-expiry policy.
