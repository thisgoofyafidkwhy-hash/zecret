const $ = (id) => document.getElementById(id);
const routeData = {
  fastest: {
    title: "Jeep + LRT-1",
    fare: "₱53",
    steps: [
      ["Start at Monumento", "Head to the designated jeepney / transport terminal. Check the signboard and ask the dispatcher."],
      ["Connect to rail", "Follow station signs and check the latest service announcements before boarding."],
      ["Continue to your destination", "Use the indicated northbound connection and follow pedestrian directions to your destination."]
    ],
    breakdown: [["Jeepney (sample)", "₱13"], ["Modern jeep (sample)", "₱15"], ["Rail (sample)", "₱25"]]
  },
  cheapest: {
    title: "Jeepney connections",
    fare: "₱26–₱35",
    steps: [
      ["Find the correct signboard", "Ask the dispatcher which jeepney serves your destination; routes can vary by terminal."],
      ["Transfer at the suggested stop", "Confirm the transfer point with the driver or dispatcher before boarding."],
      ["Walk to your destination", "Follow marked crossings and use pedestrian walkways where available."]
    ],
    breakdown: [["First jeepney (sample)", "₱13–₱18"], ["Second jeepney (sample)", "₱13–₱17"]]
  },
  accessible: {
    title: "Rail + accessible transfer",
    fare: "₱40–₱60",
    steps: [
      ["Check station access", "Confirm elevator and escalator availability with the station before starting your trip."],
      ["Use the rail connection", "Follow station accessibility signs and ask staff if you need step-free assistance."],
      ["Complete the final transfer", "Choose a transfer with fewer long walks and allow extra travel time."]
    ],
    breakdown: [["Local transport (sample)", "₱13–₱20"], ["Rail / connection (sample)", "₱27–₱40"]]
  }
};
let selectedRoute = "fastest";
let toastTimer;

function toast(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2600);
}
function renderDetails(key) {
  selectedRoute = key;
  const data = routeData[key];
  document.querySelectorAll(".route-card").forEach(card => card.classList.toggle("selected", card.dataset.route === key));
  $("detailTitle").textContent = data.title;
  $("detailFare").textContent = data.fare;
  $("steps").innerHTML = data.steps.map((step, i) => `<li><span class="step-number">${i+1}</span><div><strong>${step[0]}</strong><p>${step[1]}</p></div></li>`).join("");
  const breakdown = data.breakdown.map(item => `<div><span>${item[0]}</span><strong>${item[1]}</strong></div>`).join("");
  document.querySelector(".fare-breakdown").innerHTML = breakdown + `<div class="fare-total"><span>Estimated total</span><strong id="detailFare">${data.fare}</strong></div>`;
  $("saveStatus").textContent = "";
}
document.querySelectorAll(".route-card").forEach(card => {
  card.addEventListener("click", e => renderDetails(card.dataset.route));
});
document.querySelectorAll(".choose-route").forEach(btn => {
  btn.addEventListener("click", e => {
    e.stopPropagation();
    const card = btn.closest(".route-card");
    renderDetails(card.dataset.route);
    $("routeDetails").scrollIntoView({behavior:"smooth", block:"start"});
  });
});
$("findRoutes").addEventListener("click", () => {
  const from = $("origin").value, to = $("destination").value;
  if (from === to) {
    toast("Your starting point and destination are the same. Choose a different destination.");
    return;
  }
  $("routeCount").textContent = "3 sample routes";
  toast(`Showing sample options: ${from} → ${to}`);
  document.querySelector(".results-heading").scrollIntoView({behavior:"smooth", block:"start"});
});
$("swapBtn").addEventListener("click", () => {
  const origin = $("origin"), destination = $("destination");
  const oldOrigin = origin.value;
  const oldDestination = destination.value;
  const originOption = [...origin.options].find(o => o.text === oldDestination);
  const destinationOption = [...destination.options].find(o => o.text === oldOrigin);
  if (originOption) origin.value = oldDestination;
  else origin.selectedIndex = 0;
  if (destinationOption) destination.value = oldOrigin;
  else destination.selectedIndex = 0;
});
$("saveRoute").addEventListener("click", () => {
  const origin = $("origin").value, destination = $("destination").value;
  const data = routeData[selectedRoute];
  const saved = {origin, destination, route: data.title, fare: data.fare, steps: data.steps, savedAt: new Date().toISOString()};
  try {
    localStorage.setItem("biyahero-saved-route", JSON.stringify(saved));
    $("saveStatus").textContent = "✓ Saved on this browser. Keep this page available on your device for reference.";
    toast("Route saved on this device.");
  } catch {
    $("saveStatus").textContent = "Your browser blocked local storage. You can screenshot the route details instead.";
    toast("Storage unavailable — screenshot the route details.");
  }
});
$("reportBtn").addEventListener("click", () => {
  $("reportPanel").hidden = false;
  $("reportPanel").scrollIntoView({behavior:"smooth", block:"nearest"});
});
$("closeReport").addEventListener("click", () => $("reportPanel").hidden = true);
$("submitReport").addEventListener("click", () => {
  const location = $("reportLocation").value;
  const type = $("reportType").value;
  const note = $("reportNote").value.trim();
  const labels = {queue:"Mahaba ang pila", moving:"Pila is moving / may sakay", flood:"Baha / waterlogging", traffic:"Heavy traffic", fare:"Fare / route reminder"};
  const icons = {queue:"⌛", moving:"🚐", flood:"🌧", traffic:"🚦", fare:"₱"};
  const update = {location, type, label:labels[type], note, time:new Date().toLocaleTimeString([], {hour:"2-digit", minute:"2-digit"}), icon:icons[type]};
  let reports = [];
  try { reports = JSON.parse(localStorage.getItem("biyahero-reports") || "[]"); } catch {}
  reports.unshift(update);
  try { localStorage.setItem("biyahero-reports", JSON.stringify(reports.slice(0,20))); } catch {}
  const item = document.createElement("article");
  item.className = "update-item";
  const icon = document.createElement("span");
  icon.className = "update-icon green-bg";
  icon.textContent = update.icon;
  const content = document.createElement("div");
  const title = document.createElement("strong");
  title.textContent = `${update.label} — ${location}`;
  const p = document.createElement("p");
  p.textContent = `Just now · Your browser report`;
  const tag = document.createElement("span");
  tag.className = "report-age";
  tag.textContent = note || "Community report · Not verified";
  content.append(title, p, tag);
  item.append(icon, content);
  $("updatesList").prepend(item);
  $("reportPanel").hidden = true;
  $("reportNote").value = "";
  toast("Update added locally. It has not been sent to other commuters.");
});
$("offlineInfo").addEventListener("click", () => {
  toast("Save route stores the route details in this browser. This demo does not cache the whole website offline.");
});

// Restore a saved route for reference if one exists.
try {
  const saved = JSON.parse(localStorage.getItem("biyahero-saved-route") || "null");
  if (saved) {
    const notice = document.createElement("p");
    notice.className = "hint";
    notice.textContent = `Saved route on this device: ${saved.origin} → ${saved.destination} (${saved.route}, ${saved.fare}).`;
    $("saveRoute").insertAdjacentElement("afterend", notice);
  }
} catch {}
